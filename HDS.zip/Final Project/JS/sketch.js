var state = 't1'

document.addEventListener("click", function () {
    if (state == 't1') {
        var hiddenText = document.getElementById("t1");
        hiddenText.style.display = "block";
        state = 't2'
    } else if (state == 't2') {
        var hiddenText = document.getElementById("t2");
        hiddenText.style.display = "block";
        state = 't3'
    } else if (state == 't3') {
        var hiddenText = document.getElementById("t3");
        hiddenText.style.display = "block";
        state = 'flowup'
    } else if (state == 'b1') {
        document.getElementById("b2").style.display = "block";
        state = ''
    }
});


function setup() {
    const box = document.getElementById('main').getBoundingClientRect()
    let cnv = createCanvas(window.innerWidth, window.innerHeight)
    cnv.parent('p5')
    noStroke()
}

var phase = 0
var phase1 = 50
var topD = 0
function draw() {
    if (state !== 'flowup') return

    background(0, 0, 0, 0)

    fill(106, 147, 111)
    beginShape()
    for (let x = 0; x < width; x++) {
        let y = 50 * sin(x * 0.01 + phase) + height - 100
        y -= topD
        vertex(x, y)

        checkReachTop(y)
    }
    vertex(width, height)
    vertex(0, height)
    endShape(CLOSE)


    fill(62, 88, 66)
    beginShape()
    for (let x = 0; x < width; x++) {
        let y = 50 * sin(x * 0.01 + phase1) + height - 100
        y -= topD
        vertex(x, y)
        checkReachTop(y)
    }
    vertex(width, height)
    vertex(0, height)
    endShape(CLOSE)

    phase -= 0.005
    phase1 += 0.01
    topD += 1
}

function checkReachTop(y) { 
    if (y <= 0) {
        noLoop()
        document.getElementById("hiddenText").style.display = "none";
        document.getElementById("main").style.visibility = "hidden";
        document.getElementById("b1").style.display = "block";
        state = 'b1'
    }
}