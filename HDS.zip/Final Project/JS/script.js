    document.addEventListener("click", function() { 
      var hiddenText = document.getElementById("hiddenText"); 
      hiddenText.style.display = "block"; 
    }); 


    